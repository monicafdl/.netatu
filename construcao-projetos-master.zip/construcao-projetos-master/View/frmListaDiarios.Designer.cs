﻿namespace View
{
    partial class frmListaDiarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Codigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Disciplina = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Avaliação = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDImprimir = new System.Windows.Forms.Button();
            this.btnDFechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Codigo,
            this.Disciplina,
            this.Avaliação});
            this.dataGridView1.Location = new System.Drawing.Point(27, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(345, 224);
            this.dataGridView1.TabIndex = 0;
            // 
            // Codigo
            // 
            this.Codigo.HeaderText = "Codigo";
            this.Codigo.Name = "Codigo";
            this.Codigo.ReadOnly = true;
            // 
            // Disciplina
            // 
            this.Disciplina.HeaderText = "Disciplina";
            this.Disciplina.Name = "Disciplina";
            this.Disciplina.ReadOnly = true;
            // 
            // Avaliação
            // 
            this.Avaliação.HeaderText = "Avaliação";
            this.Avaliação.Name = "Avaliação";
            this.Avaliação.ReadOnly = true;
            // 
            // btnDImprimir
            // 
            this.btnDImprimir.Location = new System.Drawing.Point(27, 274);
            this.btnDImprimir.Name = "btnDImprimir";
            this.btnDImprimir.Size = new System.Drawing.Size(75, 23);
            this.btnDImprimir.TabIndex = 10;
            this.btnDImprimir.Text = "Imprimir";
            this.btnDImprimir.UseVisualStyleBackColor = true;
            this.btnDImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // btnDFechar
            // 
            this.btnDFechar.Location = new System.Drawing.Point(297, 274);
            this.btnDFechar.Name = "btnDFechar";
            this.btnDFechar.Size = new System.Drawing.Size(75, 23);
            this.btnDFechar.TabIndex = 9;
            this.btnDFechar.Text = "Fechar";
            this.btnDFechar.UseVisualStyleBackColor = true;
            this.btnDFechar.Click += new System.EventHandler(this.btnDFechar_Click);
            // 
            // frmListaDiarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 318);
            this.Controls.Add(this.btnDImprimir);
            this.Controls.Add(this.btnDFechar);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmListaDiarios";
            this.Text = "frmListaDiarios";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Codigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Disciplina;
        private System.Windows.Forms.DataGridViewTextBoxColumn Avaliação;
        private System.Windows.Forms.Button btnDImprimir;
        private System.Windows.Forms.Button btnDFechar;
    }
}