﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;

namespace View
{
    public partial class frmPrincipal : Form
    {

        private Dictionary<Int64, Aluno> mapaAlunos;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            this.Hide();
            
            frmLogin form = new frmLogin();

            if (form.ShowDialog() != DialogResult.OK)
            {
                this.Close();
            }
            else
            {
                this.Show();

                Usuario user = (Usuario)form.Tag;

                sUser.Text = " | Usuário logado: " + user.Login;

                tmHora.Enabled = true;

                
            }
        }

        private void tmHora_Tick(object sender, EventArgs e)
        {
            itsLabelHora.Text = DateTime.Now.ToLongTimeString();
        }

        private void cadastrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadAluno form = new frmCadAluno();

            form.ShowDialog();
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListaAlunos form = new frmListaAlunos();

            form.ShowDialog();
            
        }

        private void cadastrarAvaliaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadAvaliacao form = new frmCadAvaliacao();
            form.ShowDialog();
        }

        private void consultaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListaDiarios form = new frmListaDiarios();
            form.ShowDialog();
        }

        private void listaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListaDisciplinas form = new frmListaDisciplinas();
            form.ShowDialog();
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadDiario form = new frmCadDiario();
            form.ShowDialog();
        }

        private void cadastroToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmCadDisciplina form = new frmCadDisciplina();
            form.ShowDialog();
        }

        private void itbCadAluno_Click(object sender, EventArgs e)
        {
            frmCadAluno form = new frmCadAluno();
            form.ShowDialog();
        }

        private void itmArquivo_Click(object sender, EventArgs e)
        {

        }
    }
}
