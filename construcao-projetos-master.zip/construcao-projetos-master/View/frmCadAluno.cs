﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace View
{
    public partial class frmCadAluno : Form
    {
        private Aluno a = new Aluno();

        public frmCadAluno()
        {
            InitializeComponent();
        }

        private void btnAluCadastrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cadastrado");
        }

        private void btnAluAlterar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alterado");
        }

        private void btnAluCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
