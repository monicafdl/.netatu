﻿namespace View
{
    partial class frmCadAluno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAluCadastrar = new System.Windows.Forms.Button();
            this.gpbPessoas = new System.Windows.Forms.GroupBox();
            this.txtCodDiario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lbtAvaliacoesAlu = new System.Windows.Forms.ListBox();
            this.lblAvaliacoesAlu = new System.Windows.Forms.Label();
            this.lblDiarioAl = new System.Windows.Forms.Label();
            this.lblNomeAl = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.btnAluCancelar = new System.Windows.Forms.Button();
            this.btnAluAlterar = new System.Windows.Forms.Button();
            this.gpbPessoas.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAluCadastrar
            // 
            this.btnAluCadastrar.Location = new System.Drawing.Point(12, 225);
            this.btnAluCadastrar.Name = "btnAluCadastrar";
            this.btnAluCadastrar.Size = new System.Drawing.Size(94, 23);
            this.btnAluCadastrar.TabIndex = 0;
            this.btnAluCadastrar.Text = "Cadastrar";
            this.btnAluCadastrar.UseVisualStyleBackColor = true;
            this.btnAluCadastrar.Click += new System.EventHandler(this.btnAluCadastrar_Click);
            // 
            // gpbPessoas
            // 
            this.gpbPessoas.Controls.Add(this.txtCodDiario);
            this.gpbPessoas.Controls.Add(this.txtNome);
            this.gpbPessoas.Controls.Add(this.txtMatricula);
            this.gpbPessoas.Controls.Add(this.lbtAvaliacoesAlu);
            this.gpbPessoas.Controls.Add(this.lblAvaliacoesAlu);
            this.gpbPessoas.Controls.Add(this.lblDiarioAl);
            this.gpbPessoas.Controls.Add(this.lblNomeAl);
            this.gpbPessoas.Controls.Add(this.lblMatricula);
            this.gpbPessoas.Location = new System.Drawing.Point(12, 12);
            this.gpbPessoas.Name = "gpbPessoas";
            this.gpbPessoas.Size = new System.Drawing.Size(310, 207);
            this.gpbPessoas.TabIndex = 7;
            this.gpbPessoas.TabStop = false;
            this.gpbPessoas.Text = "Dados de Alunos";
            // 
            // txtCodDiario
            // 
            this.txtCodDiario.Location = new System.Drawing.Point(98, 102);
            this.txtCodDiario.Name = "txtCodDiario";
            this.txtCodDiario.Size = new System.Drawing.Size(100, 20);
            this.txtCodDiario.TabIndex = 8;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(98, 63);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 7;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(98, 29);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 6;
            // 
            // lbtAvaliacoesAlu
            // 
            this.lbtAvaliacoesAlu.FormattingEnabled = true;
            this.lbtAvaliacoesAlu.Location = new System.Drawing.Point(98, 141);
            this.lbtAvaliacoesAlu.Name = "lbtAvaliacoesAlu";
            this.lbtAvaliacoesAlu.Size = new System.Drawing.Size(100, 56);
            this.lbtAvaliacoesAlu.TabIndex = 5;
            // 
            // lblAvaliacoesAlu
            // 
            this.lblAvaliacoesAlu.AutoSize = true;
            this.lblAvaliacoesAlu.Location = new System.Drawing.Point(21, 141);
            this.lblAvaliacoesAlu.Name = "lblAvaliacoesAlu";
            this.lblAvaliacoesAlu.Size = new System.Drawing.Size(59, 13);
            this.lblAvaliacoesAlu.TabIndex = 3;
            this.lblAvaliacoesAlu.Text = "Avaliações";
            // 
            // lblDiarioAl
            // 
            this.lblDiarioAl.AutoSize = true;
            this.lblDiarioAl.Location = new System.Drawing.Point(10, 102);
            this.lblDiarioAl.Name = "lblDiarioAl";
            this.lblDiarioAl.Size = new System.Drawing.Size(70, 13);
            this.lblDiarioAl.TabIndex = 2;
            this.lblDiarioAl.Text = "Codigo Diario";
            // 
            // lblNomeAl
            // 
            this.lblNomeAl.AutoSize = true;
            this.lblNomeAl.Location = new System.Drawing.Point(42, 66);
            this.lblNomeAl.Name = "lblNomeAl";
            this.lblNomeAl.Size = new System.Drawing.Size(38, 13);
            this.lblNomeAl.TabIndex = 1;
            this.lblNomeAl.Text = "Nome:";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(27, 29);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(53, 13);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula:";
            // 
            // btnAluCancelar
            // 
            this.btnAluCancelar.Location = new System.Drawing.Point(225, 225);
            this.btnAluCancelar.Name = "btnAluCancelar";
            this.btnAluCancelar.Size = new System.Drawing.Size(97, 23);
            this.btnAluCancelar.TabIndex = 8;
            this.btnAluCancelar.Text = "Cancelar";
            this.btnAluCancelar.UseVisualStyleBackColor = true;
            this.btnAluCancelar.Click += new System.EventHandler(this.btnAluCancelar_Click);
            // 
            // btnAluAlterar
            // 
            this.btnAluAlterar.Location = new System.Drawing.Point(126, 225);
            this.btnAluAlterar.Name = "btnAluAlterar";
            this.btnAluAlterar.Size = new System.Drawing.Size(84, 23);
            this.btnAluAlterar.TabIndex = 9;
            this.btnAluAlterar.Text = "Alterar";
            this.btnAluAlterar.UseVisualStyleBackColor = true;
            this.btnAluAlterar.Click += new System.EventHandler(this.btnAluAlterar_Click);
            // 
            // frmCadAluno
            // 
            this.ClientSize = new System.Drawing.Size(331, 269);
            this.Controls.Add(this.btnAluAlterar);
            this.Controls.Add(this.btnAluCancelar);
            this.Controls.Add(this.gpbPessoas);
            this.Controls.Add(this.btnAluCadastrar);
            this.Name = "frmCadAluno";
            this.gpbPessoas.ResumeLayout(false);
            this.gpbPessoas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gpbDadosPrincipais;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.TextBox txbNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txbDiario;
        private System.Windows.Forms.Label lblDiario;
        private System.Windows.Forms.PictureBox ptbFoto;
        private System.Windows.Forms.Label lblFoto;
        private System.Windows.Forms.OpenFileDialog janelaAbrirArquivo;
        private System.Windows.Forms.TextBox txtMat;
        private System.Windows.Forms.Label lblAvaliacoes;
        private System.Windows.Forms.ListBox ltbAvaliacoes;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAluCadastrar;
        private System.Windows.Forms.GroupBox gpbPessoas;
        private System.Windows.Forms.TextBox txtCodDiario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.ListBox lbtAvaliacoesAlu;
        private System.Windows.Forms.Label lblAvaliacoesAlu;
        private System.Windows.Forms.Label lblDiarioAl;
        private System.Windows.Forms.Label lblNomeAl;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Button btnAluCancelar;
        private System.Windows.Forms.Button btnAluAlterar;
    }
}