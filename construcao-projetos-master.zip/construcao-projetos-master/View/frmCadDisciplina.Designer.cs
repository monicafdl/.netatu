﻿namespace View
{
    partial class frmCadDisciplina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDiCodigo = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.cbxDescricao = new System.Windows.Forms.ComboBox();
            this.btnDiCadastrar = new System.Windows.Forms.Button();
            this.btnDiCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDiCodigo
            // 
            this.lblDiCodigo.AutoSize = true;
            this.lblDiCodigo.Location = new System.Drawing.Point(30, 50);
            this.lblDiCodigo.Name = "lblDiCodigo";
            this.lblDiCodigo.Size = new System.Drawing.Size(104, 13);
            this.lblDiCodigo.TabIndex = 0;
            this.lblDiCodigo.Text = "Codigo da disciplina:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(140, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 1;
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Location = new System.Drawing.Point(30, 84);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(58, 13);
            this.lblDescricao.TabIndex = 2;
            this.lblDescricao.Text = "Descrição:";
            // 
            // cbxDescricao
            // 
            this.cbxDescricao.FormattingEnabled = true;
            this.cbxDescricao.Items.AddRange(new object[] {
            "Matemática",
            "Português",
            "História",
            "Geografia",
            "Inglês ",
            "Espanhol"});
            this.cbxDescricao.Location = new System.Drawing.Point(140, 84);
            this.cbxDescricao.Name = "cbxDescricao";
            this.cbxDescricao.Size = new System.Drawing.Size(121, 21);
            this.cbxDescricao.TabIndex = 3;
            // 
            // btnDiCadastrar
            // 
            this.btnDiCadastrar.Location = new System.Drawing.Point(33, 180);
            this.btnDiCadastrar.Name = "btnDiCadastrar";
            this.btnDiCadastrar.Size = new System.Drawing.Size(75, 23);
            this.btnDiCadastrar.TabIndex = 4;
            this.btnDiCadastrar.Text = "Cadastrar";
            this.btnDiCadastrar.UseVisualStyleBackColor = true;
            this.btnDiCadastrar.Click += new System.EventHandler(this.btnDiCadastrar_Click);
            // 
            // btnDiCancelar
            // 
            this.btnDiCancelar.Location = new System.Drawing.Point(221, 180);
            this.btnDiCancelar.Name = "btnDiCancelar";
            this.btnDiCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnDiCancelar.TabIndex = 5;
            this.btnDiCancelar.Text = "Cancelar";
            this.btnDiCancelar.UseVisualStyleBackColor = true;
            this.btnDiCancelar.Click += new System.EventHandler(this.btnDiCancelar_Click);
            // 
            // frmCadDisciplina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 269);
            this.Controls.Add(this.btnDiCancelar);
            this.Controls.Add(this.btnDiCadastrar);
            this.Controls.Add(this.cbxDescricao);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblDiCodigo);
            this.Name = "frmCadDisciplina";
            this.Text = "frmCadDisciplina";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDiCodigo;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.ComboBox cbxDescricao;
        private System.Windows.Forms.Button btnDiCadastrar;
        private System.Windows.Forms.Button btnDiCancelar;
    }
}